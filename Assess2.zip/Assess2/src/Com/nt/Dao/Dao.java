package Com.nt.Dao;

import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.nt.beans.Cars;

public class Dao {
	String url = "jdbc:mysql://localhost:3306/std";
	String user = "root";
	String password = "Quad@2022";

	private String allOldCars = "select * from oldcars ";
	private String users="select * from carusers where username=? && password=?";
    private String newUser="insert into carusers values(?,?)";
    private String car_By_Id="select * from oldcars where id=?";
    private String get_ALL_Orders="Select * from orders";
    private String insert_Order="insert into orders(Model,Price,Type,Name,contact) values (?,?,?,?,?)";

    
    
	protected Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = (Connection) DriverManager.getConnection(url, user, password);
			System.out.println("DbConnected");
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("DBConnection Problem");
			e.printStackTrace();
		}
		return con;
	}

	public List<Cars> getOldCarsList() throws SQLException {
		List<Cars> list=new ArrayList<Cars>();
		try (Connection con = getConnection();
				PreparedStatement pst = con.prepareStatement(allOldCars);) {
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
              String name=rs.getString(1);
              Date rcDate=rs.getDate(2);
              Float trDistance=rs.getFloat(3);
              String ownerType=rs.getString(4);
              Long ph=rs.getLong(5);
              float minVal=rs.getFloat(6);
              float maxVal=rs.getFloat(7);
              int id=rs.getInt(8);
              list.add(new Cars(name,rcDate,trDistance,ownerType,ph,minVal,maxVal,id));
			}
		}
		/*System.out.println(list.size());*/

		return list;
	}
           
	public int validateUser(String name,String pass) throws SQLException{
		
		int i=0;
		try(Connection con = getConnection();
				PreparedStatement pst = con.prepareStatement(users);){
			pst.setString(1,name);
			pst.setString(2,pass);
			ResultSet rs = pst.executeQuery();
			while(rs.next()){
				i++;
			}
		}
		
		return i;
	}
	
	public int registerUser(String name,String pass) throws SQLException{
		int i=0;
		try(Connection con = getConnection();
				PreparedStatement pst = con.prepareStatement(newUser);){
			pst.setString(1,name);
			pst.setString(2,pass);
			int rs = pst.executeUpdate();
			if(rs >0){
				i++;
			}
		}
		
		return i;
	}
	   
	
	public List<Cars> getCarDetailsById(int id) throws SQLException{
		List<Cars> list=new ArrayList<Cars>();
		try(Connection con = getConnection();
				PreparedStatement pst = con.prepareStatement(car_By_Id);){
                 pst.setInt(1,id);
                 ResultSet rs = pst.executeQuery();
     			while (rs.next()) {
                   String name=rs.getString(1);
                   Date rcDate=rs.getDate(2);
                   Float trDistance=rs.getFloat(3);
                   String ownerType=rs.getString(4);
                   Long ph=rs.getLong(5);
                   float minVal=rs.getFloat(6);
                   float maxVal=rs.getFloat(7);
                   int id1=rs.getInt(8);
                   list.add(new Cars(name,rcDate,trDistance,ownerType,ph,minVal,maxVal,id1));
     			}
		}
	
	           return list;
	}
	
	public int placeOrder(String Model,Float Price,String Type,String Name,Long ph) throws SQLException{
	int r=0;
		try(Connection con = getConnection();
				PreparedStatement pst = con.prepareStatement(insert_Order);){
			pst.setString(1,Model);
			pst.setFloat(2,Price);
			pst.setString(3, Type);
			
			pst.setString(4, Name);
			pst.setLong(5,ph);
			 r=pst.executeUpdate();
				if(r>0){
					System.out.println("one record  to Store");
				
					
				}else{
					System.out.println(" unable to   is Stored");
				

				}
		}
		return r;
	}
}
