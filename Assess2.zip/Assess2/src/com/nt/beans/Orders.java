package com.nt.beans;

import java.util.Date;

public class Orders {
 private int id;
 private String Model;
 private double Price;
 private String fuelType;
 private Date bookingDate;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getModel() {
	return Model;
}
public void setModel(String model) {
	Model = model;
}
public double getPrice() {
	return Price;
}
public void setPrice(double price) {
	Price = price;
}
public String getFuelType() {
	return fuelType;
}
public void setFuelType(String fuelType) {
	this.fuelType = fuelType;
}
public Date getBookingDate() {
	return bookingDate;
}
public void setBookingDate(Date bookingDate) {
	this.bookingDate = bookingDate;
}
@Override
public String toString() {
	return "Orders []";
}
public Orders(int id, String model, double price, String fuelType,
		Date bookingDate) {
	super();
	this.id = id;
	Model = model;
	Price = price;
	this.fuelType = fuelType;
	this.bookingDate = bookingDate;
}
public Orders() {
	super();
}
 
 
 
}
