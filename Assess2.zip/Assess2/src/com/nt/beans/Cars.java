package com.nt.beans;

import java.util.Date;

public class Cars {
	private String carModelName;
	private Date registrationDate;
	private double travelledKms;
	private String ownerType;
	private long phno;
	private float minval;
	private float maxval;
	private int id;

	public Cars(String carModelName, Date registrationDate,
			double travelledKms, String ownerType, long phno, float minval,
			float maxval, int id) {
		super();
		this.carModelName = carModelName;
		this.registrationDate = registrationDate;
		this.travelledKms = travelledKms;
		this.ownerType = ownerType;
		this.phno = phno;
		this.minval = minval;
		this.maxval = maxval;
		this.id = id;
	}

	public Cars(String carModelName) {
		super();
		this.carModelName = carModelName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Cars() {
		super();
	}

	public String getCarModelName() {
		return carModelName;
	}

	public void setCarModelName(String carModelName) {
		this.carModelName = carModelName;
	}

	public Date getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(Date registrationDate) {
		this.registrationDate = registrationDate;
	}

	public double getTravelledKms() {
		return travelledKms;
	}

	public void setTravelledKms(double travelledKms) {
		this.travelledKms = travelledKms;
	}

	public String getOwnerType() {
		return ownerType;
	}

	public void setOwnerType(String ownerType) {
		this.ownerType = ownerType;
	}

	public long getPhno() {
		return phno;
	}

	public void setPhno(long phno) {
		this.phno = phno;
	}

	public float getMinval() {
		return minval;
	}

	public void setMinval(float minval) {
		this.minval = minval;
	}

	public float getMaxval() {
		return maxval;
	}

	public void setMaxval(float maxval) {
		this.maxval = maxval;
	}

}
