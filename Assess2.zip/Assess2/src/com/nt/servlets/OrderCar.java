package com.nt.servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Com.nt.Dao.Dao;

/**
 * Servlet implementation class NewCar
 */
@WebServlet("/OrderCar")
public class OrderCar extends HttpServlet {
	
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String Name=request.getParameter("Name");
		String Model=request.getParameter("Model");
		Float Price=Float.parseFloat(request.getParameter("Price"));
		String Type=request.getParameter("Type");
		Long ph=Long.parseLong(request.getParameter("Phone"));
		System.out.println(Name+"-"+ph+"-"+Model+"-"+Price+"-"+Type);
	     Dao d=new Dao();
	    
		try {
			int result=d.placeOrder(Model,Price,Type, Name, ph);
			
			if(result>0){
				System.out.println("order placed Success");
				response.sendRedirect("index.jsp");
			}else{
				System.out.println("Unable to insert order");
				/*response.sendRedirect("usedCars.jsp");*/
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Error:OrderCar.doPost()");
		}
	}

}
