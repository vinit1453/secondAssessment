package com.nt.con;

import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import com.mysql.jdbc.Connection;

/**
 * Application Lifecycle Listener implementation class DbConnection
 *
 */
@WebListener
public class DbConnection implements HttpSessionListener {
	String url="jdbc:mysql://localhost:3306/std" ; 
    String user="root" ; 
    String password="Quad@2022" ;
     
     Connection con;
    public void sessionCreated(HttpSessionEvent hse)  { 
         try {
			Class.forName("com.mysql.jdbc.Driver"); 
			 con=(Connection)DriverManager.getConnection(url, user, password);
			 HttpSession session=hse.getSession();
			 session.setAttribute("Connection",con);
			 System.out.println("DbConnected");
		} catch (ClassNotFoundException |SQLException e) {
			System.out.println("DBConnection Problem");
			e.printStackTrace();
		} 
    }

	
    public void sessionDestroyed(HttpSessionEvent arg)  { 
         // TODO Auto-generated method stub
    }
	
}
